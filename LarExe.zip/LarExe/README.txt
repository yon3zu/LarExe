You Can Also use Domain List ( list don't use http:// or https:// )
for best and good result

# This Tools Coded By #No_Identity - XploitSec Team
# Find Me : https://t.me/xxyz4
# Find Us : https://t.me/exploi7
# Our Site : https://tools.xploitsecid.or.id
# youtube : https://www.youtube.com/channel/UCDYnCkZ23uK4W2AxVG78pWA

If U Need Full Course For Shells,SMtps,CPanels,Fresh Web List For shells and smtps with private tools and method
Just Contact : https://t.me/xxyz4

Indonesian Hacker Rulez